#include "BoundaryConditions.h"

BoundaryConditions::BoundaryConditions(int grid, float diffusion){

}